
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('habilidad-toggle');
  const lista = document.getElementById('habilidades-list');

  const tecnicas = ['HTML', 'CSS', 'JavaScript', 'APIs Test'];
  const blandas = ['Creatividad', 'Empatía', 'Adaptabilidad', 'Disciplina', 'Comunicación'];

  function mostrarHabilidades(tipo) {
    lista.innerHTML = '';
    const habilidades = tipo === 'tecnicas' ? tecnicas : blandas;
    habilidades.forEach(hab => {
      const div = document.createElement('div');
      div.className = 'habilidad';
      div.textContent = hab;
      lista.appendChild(div);
    });
  }

  mostrarHabilidades('tecnicas');

  toggle.addEventListener('change', () => {
    mostrarHabilidades(toggle.checked ? 'blandas' : 'tecnicas');
  });
});
